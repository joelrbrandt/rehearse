// Draw a 2D slice of the RGB color space
// x-axis: red
// y-axis: green

int r; // red (0..255)
int g; // green (0..255)
int b=128; // blue (0..255)

void setup() {
  // make window size 256x256 so every color value gets one pixel
  size(256,256);
  
  // iterate over 256 values for red
  for(r=0; r<width; r++) {
    //iterate over 256 values for green
    for(g=0; g<height; g++) {
      //at position (x,y) draw a pixel of color(red=x,green=y,blue=128)
      stroke(r,g,b);
      point(r,g);
    }
  }
}

