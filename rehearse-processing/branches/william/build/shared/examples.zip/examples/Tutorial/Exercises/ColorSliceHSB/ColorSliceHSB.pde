// Draw a 2D slice of the HSB color space
// and a hue bar next to it as in the OS X color picker

int h=0; // hue (0..255)
int s; // saturation (0..255)
int b; // brightness (0..255)

void setup() {
  //switch colorMode from RGB to HSB
  
  //make window size (256+16)x256
 
  // draw the color slice in the first 256x256 pixels:
  // iterate over 256 values for saturation
  
    // iterate over 256 values for brightness
  
      //at position (x,y) draw a pixel of color
      //(saturation=x,brightness=y,hue=h)
      //note: to make the slice look like the color picker on osx,
      //invert the y coordinate
      
  // draw the hue bar
  // iterate over 256 values for hue 
 
    // draw a horizontal line of color (hue,255,255)
    // from points(256,y) to (width,y)
 
 
}

