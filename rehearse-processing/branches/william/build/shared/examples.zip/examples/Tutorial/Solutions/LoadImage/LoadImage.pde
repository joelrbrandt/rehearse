// LoadImage
// example demonstrates how to work with both 
// SVG vector graphics files and 
// PNG raster graphics files 

PImage img;
PShape shp;

void setup() {

  size(200,200);
  smooth();
  // load a raster image from data directory
  img = loadImage("ring.png");
  // make sure coordinates are relative to center of image
  imageMode(CENTER);
  
  // load a vector graphics image from data directory
  shp = loadShape("ring.svg");
  // translate it so coordinate are again relative to center of image
  shp.translate(-shp.width/2,-shp.height/2);
}


void draw() {
  //clear screen
  background(128);

  // move coordinate system to mouse   
  translate(mouseX,mouseY);
  
  
  pushMatrix();
  //dynamically scale and rotate shape to make shape more interesting
  scale(0.7+0.1*sin(radians(frameCount)));
  rotate(radians(frameCount));
  // draw vector shape
  shape(shp,0,0);
  popMatrix();
  
  // draw raster image (also rotated)
  rotate(-1*radians(frameCount));
  image(img,0,0);
  
  
  
}


