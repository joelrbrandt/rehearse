// MondrianClick
// draw Mondrian-like graphics where
// lines are generated automatically,
// but color fields are painted by the user with mouse clicks.
// colors are chosen using the keyboard.

color red = color(255,0,0);
color yellow = color(255,255,0);
color blue = color(0,0,255);
color white = color(255,255,255);
color black = color(0,0,0);
color fillColor = red;

void setup() {
  size(200,200);
  drawLines();
}

// handle drawing of horizontal and vertical lines
void drawLines() {
  float x,y;
  
  strokeWeight(3);   // make the stroke a bit fatter
  
  background(white);
  stroke(black); //make it black

  //draw some random horizontal lines
  int hLines = 4; //this many lines
  for(int i=0; i<hLines; i++) {
    x=random(width);
    line(x,0,x,height);
  }

  //draw some random vertical lines
  int vLines=5;
  for(int i=0; i<vLines; i++) {
    y=random(height);
    line(0,y,width,y);
  }
}

// handle mouse clicks in a separate function:
// call boxFill on mouse coordinates, with black as stop color
// and the currently selected color as fill color
void mouseClicked(){
}

// handle key presses:
void keyPressed() {
  // 'r' key: set color to red
  // 'y' key: set color to yellow
  // 'b' key: set color to blue
  // 'w' key: set color to white
  // ' ' (space): redraw all lines
  // 's' key: save current graphics to file
}


void draw(){
}



