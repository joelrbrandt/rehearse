//2D Bounce
// Example of gravity physics simulation
// A white box bounces off ground and side walls

float x; // x position
float y; // y position
float vx=5; // x velocity - give non-zero initial value
float vy=0; // initial y velocity
float ax=0.0; // no gravity in x direction!
float ay=0.1; // gravity in y direction

void setup() {
  size(200,200);
  noStroke();
  fill(255);
  smooth();
  //set x,y to start out on top of window, in middle of row.
  x=width/2; 
  y=0;
}

void draw() {
  
  // fading trick: draw semi-transparent rectangle on 
  // top of previous graphics to fade them out

  
  //update positions pos = pos + velocity for x and y

  //update velocity = velocity + acceleration for x and y

  
  // handle bounce off bottom:
  // if y position > bottom of screen
 
    //reverse y velocity, dampen a bit

  // handle bounce off left/right sides:
  // if x position is off screen, reverse x velocity
  // and dampen
 
 
  // set fill to white and
  // finally draw our rectangle
  fill(255);
  rect(x,y,10,10);
}
