// SnakeArray:
// draw a snake that follows the mouse using arrays

// declare two arrays that hold x,y coordinates
// of snake
int xs[] = new int[50];
int ys[] = new int[50];


void setup() {
  size(150,150);
  smooth();
  colorMode(HSB);
  strokeWeight(3); 
  
  //initialize all array elements to 0
}


void draw() {
  //clear screen
  background(64);

  //shift arrays over by one
  
  //if mouse pressed, save mouse position at head of array
  
  //now draw what's in our array
  //iterate over arrays
    // optional: set a different hue for each element of the snake
    // optional: make stroke thicker at the beginning of the snake
    //   and thinner towards the end
    //draw a line from one snake point to the next
  
}

