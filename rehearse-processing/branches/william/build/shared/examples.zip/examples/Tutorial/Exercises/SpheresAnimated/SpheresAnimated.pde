// SpheresAnimated - understanding hierarchical transformations
// 12 spheres are rotating around a central sphere.
// each of those spheres has another 12 smaller spheres rotating around it.

// how many sectors do we want to subdivide a circle into?
int sectors = 12;

// the central angle of each sector in radians? (360 degrees/sectors) in radians 
float angle = radians(360/sectors);

// two variables to keep track of current rotations-
// one clockwise and one counterclockwise
float rotCCW =0;
float rotCW =0;

void setup() {
  size(150,150);
  noStroke();
  smooth();
}

void draw() {
  //redraw everything every frame - clear background
  background(128);
  
  // rotate a little further each frame
  rotCCW+=0.01;
  rotCW-=0.01;
  

  //move coordinate system origin to center of window
  translate(width/2,height/2);
  
  //apply rotation matrix to rotate a bit every frame

  
  //draw the center sphere
  ellipse(0,0,10,10);

  // iterate of each sector to draw orbiting spheres:
  for(int i=0; i<sectors; i++) {
    //save current transformation so we can restore it later
    pushMatrix();
    //rotate to i-th sector
    rotate(i*angle);
    // move away from the center along the x axis of the rotated coord system 
    translate(mouseX,0);
    // draw a smaller sphere
    ellipse(0,0,8,8);
    
    // now repeat the same process again to draw 2nd level of orbiting spheres
    rotate(rotCW);
    
    //iterate over each sector
      //save matrix
      //rotate to j-th angle
      //translate out 
      //draw smaller ellipse
      //restore matrix
    
    //restore the saved coordinate system
    popMatrix();
  }
}

