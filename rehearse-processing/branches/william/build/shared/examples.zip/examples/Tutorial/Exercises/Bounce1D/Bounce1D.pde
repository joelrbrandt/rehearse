// 1D Bounce
// Example of gravity physics simulation
// A white box falls down, bounces off ground

float x,y; // position
float vy=0; // initial y velocity
float ay=0.2; // gravity in y direction

void setup() {
  size(200,200);
  noStroke();
  fill(255);
  smooth();
  //set x,y to start out on top of window, in middle of row.
  x=width/2; 
  y=0;
}

void draw() {
  // fading trick: draw semi-transparent rectangle on 
  // top of previous graphics to fade them out


  //calculate new simulation values:
  //update positions pos = pos + velocity
  
  //update velocity = velocity + acceleration
  
  // handle bounce off bottom:
  // if y position > bottom of screen
  
    // reverse y velocity, dampen a bit
    // jiggle y position so we don't reverse direction again next time
  
  
  // set fill to white and
  // finally draw our rectangle
  rect(x,y,10,10);
}



