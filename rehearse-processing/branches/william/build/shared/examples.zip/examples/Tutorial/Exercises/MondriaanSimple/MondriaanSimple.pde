// mondriaan_00

void setup() {
  
  // make our canvas 200 x 200 pixels large
  
  // set background to white
  
  // don't draw outlines around rectangles
  
  // draw some colored rectangles
  // set fill color to red
  
  // draw rect with upper left corner at (10,10)
  // and width and height of 50 
  
  //set fill color to blue
  
  // draw rect with upper left corner at (0,60)
  // width 10 and height 80
  
  // set fill color to yellow
  
  // draw rect with upper left corner at (60,140)
  // and width 10, height 10
  
  // now draw lines in black
  // turn off fill
  
  // set stroke color to black
  
  // set the width of the stroke to 3 pixels
  

  // draw horizontal lines
  // draw line from (0,10) to (200,10)
  line(0,10,width,10);

  // draw line from (0,60) to (200,60)

  // draw line from (0,140) to (200,140)

  // draw line from (0,150) to (200,150)
  
  // draw vertical lines
  // draw line from (10,0) to (10,200)
  line(10,0,10,height);
  // draw line from (60,0) to (60, 200)
}

