// boxFill2
// a functions that, given a point (x,y), finds the 
// largest rectangular box of target color,
// and replaces it with the replacement color

void boxFill(int x, int y, color stop, color replacement) {
  loadPixels();
  if(pixels[y*width+x]==stop)
    return;
  //find minx
  int minx = x;
  while(minx > 0) {
    if(pixels[y*width+(minx-1)]==stop)
      break;
     minx--;
  }
  //find maxx
  int maxx=x;
  while(maxx<(width-1)) {
    if(pixels[y*width+(maxx+1)]==stop)
      break;
     maxx++;
  }
  
  //find miny
  int miny=y;
  while(miny > 0) {
    if(pixels[(miny-1)*width+x]==stop)
      break;
     miny--;
  }
  
  //find maxy
  int maxy = y;
  while(maxy<(height-1)) {
    if(pixels[(maxy+1)*width+x]==stop)
      break;
    maxy++;
  }
  //draw rect 
  fill(replacement);
  noStroke();
  rect(minx,miny,maxx-minx+1,maxy-miny+1);
}
