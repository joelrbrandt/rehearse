//SnakeFade:
//draw a trail behind the mouse whenever the mouse button is pressed down

void setup() {
  size(150,150);  
  strokeWeight(4); 
  smooth();
}

void draw() {
  //draw a large gray rectangle on top of existing graphics with
  //high transparency (low opacity) to fade existing graphics
  
  // now draw a white line from the previous mouse position to the 
  // current mouse position if mouse is pressed


}



