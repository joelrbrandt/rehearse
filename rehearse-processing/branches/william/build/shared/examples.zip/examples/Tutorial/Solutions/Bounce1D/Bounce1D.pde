// 1D Bounce
// Example of gravity physics simulation
// A white box falls down, bounces off ground

float x,y; // position
float vy=0; // initial y velocity
float ay=0.2; // gravity in y direction

void setup() {
  size(200,200);
  noStroke();
  fill(255);
  smooth();
  //set x,y to start out on top of window, in middle of row.
  x=width/2; 
  y=0;
}

void draw() {
  // fading trick: draw semi-transparent rectangle on 
  // top of previous graphics to fade them out
  fill(0,50);
  rect(0,0,width,height);

  //calculate new simulation values:
  //update positions pos = pos + velocity
  y = y+vy;

  //update velocity = velocity + acceleration
  vy = vy+ay;

  // handle bounce off bottom:
  // if y position > bottom of screen
  if(y>height-10) {

    // reverse y velocity, dampen a bit
    vy*=-0.80;
    // jiggle y position so we don't reverse direction again next time
    y=height-10;
  
  }

  // set fill to white and
  // finally draw our rectangle
  fill(255);
  rect(x,y,10,10);
}



