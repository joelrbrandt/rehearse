public class Letter {
  char _l;
  int _x;
  float _y;
  int _age = 0;
  float gravity = 0.5;
  float speed=0;
  public Letter(char l,int x, int y) {
    _l=l;
    _x=x;
    _y=y;
  }
  public void draw() {
    _age++;
    if (_age>10) {
      _y = _y+speed;
      speed = speed+gravity;
      if(_y > height) {
        if(speed > 0.000001) {
        speed = speed* -0.35;
        } else {
          speed=0;
          gravity=0;
        }
      }
      
    }
    text(str(_l),_x,_y);
  }
  
}

