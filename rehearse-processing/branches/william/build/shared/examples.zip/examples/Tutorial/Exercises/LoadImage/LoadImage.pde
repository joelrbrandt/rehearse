// LoadImage
// example demonstrates how to work with both 
// SVG vector graphics files and 
// PNG raster graphics files 

PImage img;
PShape shp;

void setup() {

  size(200,200);
  smooth();
  // load a raster image "ring.png" from data directory
  
  // make sure coordinates are relative to center of image
  imageMode(CENTER);
  
  // load a vector graphics image "ring.svg" from data directory
  
  // translate it so coordinate are again relative to center of image

}


void draw() {
  //clear screen
  background(128);

  // move coordinate system to mouse   
  translate(mouseX,mouseY);
  
  // draw vector shape here
  
  // draw raster image (also rotated)

  
  
}


