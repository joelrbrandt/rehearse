// TextTicker
// show entered text letter by letter; text fades out

PFont font; //font variable to hold loaded font
int x=5; //initial x,y coordinates of text
int y=41;

void setup() {
  size(360,50);
  background(0);
  //load font and set it as the current textFont
  font = loadFont("Monospaced-36.vlw"); 
  textFont(font);
}

void draw() {
  //perform the fading trick
  fill(0,0,0,1);
  rect(0,0,width,height);
}

//function to handle character/key input:
void keyTyped() {
  //set fill color for text
  fill(0, 102, 153);
  //write text on screen at position (x,y)
  text(str(key),x,y);
  //increase x
  x=x+36;
  //if x has moved off the screen, return x to the left edge of the screen
  if(x>width) {
    x=5;
  }
  redraw();
}


