//Draw a HSB color picker 
//Choose a Hue on the side bar with a mouse click,
//then print HSB and RGB color values to the console
//when the user clicks inside the main color slice

int h=0; //hue

void setup() {
  colorMode(HSB);
  size(256+16,256);
  drawSlice(h);
  drawBar();
}

// empty draw function - all action happens in mouse handler function
void draw() {}

// draw a 2D slice of HSB space at the hue given by variable hue
// into the first 256x256 pixels
void drawSlice(int h) {
      //at position (x,y) draw a pixel of color(red=x,green=y,blue=128)
}

// draw the hue bar on the right side of the window
void drawBar() {
  // iterate over 256 possible hue values
  
    //draw a line of color (hue, 255,255)
    //from (256,hue) to (width,hue)
    
  
}

// function that is called when the mouse button is pressed
void mousePressed() {

    // picked a color in the main field:
    // print HSB and RGB values to console


    //picked a new hue on the hue bar:
    //save value and redraw the 2d slice
}
