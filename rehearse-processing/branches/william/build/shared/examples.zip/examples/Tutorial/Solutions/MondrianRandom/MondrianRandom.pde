// Mondrian version 2
// generate lines and fills randomly

void setup() {
  
  //some variables we'll need:
  int x,y; // hold generated x and y coordinates
  color c; // hold generated color
  color white = color(255);
  color black = color(0);
  color colors[] = {color(255,0,0),color(0,0,255),color(255,255,0)};
  
  //set size to 200x200 pixels
  size(200,200);
  //set background to white
  background(white); 
  
  strokeWeight(3);   // make the stroke 3 pixels wide
  stroke(0); // make it black

  // draw some vertical lines
  int vLines = 4; //this many lines
  //for each line:
  for(int i=0; i<vLines; i++) {
    // generate a random x coordinate
    x=int(random(width));
    // draw a line from (x,0) to (x,height)
    line(x,0,x,height);
  }

  //draw some horizontal lines
  int hLines=3; //this many lines
  //for each line:
  for(int i=0; i<hLines; i++) {
    // generate a random y coordinate
    y=int(random(height));
    //draw a line from (0,y) to (width,y)
    line(0,y,width,y);
  }

  //fill the space in between lines with primary colors
  int fields = 4; // this many color fields
  
  //for each field
  for(int i=0; i<fields; i++) {
    //pick a random x,y coordinate
    x = int(random(width));
    y = int(random(height));
    //and a random primary color
    c = colors[int(random(colors.length))];
    // fill it in using the boxFill() algorithm
    boxFill(x,y,black,c);
  }
}

