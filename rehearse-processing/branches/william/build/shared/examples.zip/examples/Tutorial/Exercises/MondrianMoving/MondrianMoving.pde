// MondrianMoving
// animated version: lines are moved using Perlin noise
// we'll use 4 horizontal lines, 4 vertical lines and 3 color fields

// arrays to store line starting points
int[] xs = new int[4];
int[] ys = new int[4];

// arrays to store color field starting points 
int[] colorxs = new int[3];
int[] colorys = new int[3];

void setup() {
  size(200,200);
  smooth();
  //generate random x coordinates and y coordinates for lines
  //(set xs[] and ys[])
  for(int i=0; i<4; i++) {
    xs[i] = int(random(width));
    ys[i] = int(random(height));
  }
  
  // generate random x and y coordinates for color fills
  // (set colorxs, colorys)
  for(int i=0; i<3; i++) {
    colorxs[i] = int(random(width));
    colorys[i] = int(random(height)); 
  }
}

void draw() {
  // redraw entire window every frame
  // variables to hold position of moved lines
  float x,y; // make these float for smoother animation
  background(255); // paint canvas white 

  // set stroke to black and draw horizontal and vertical lines
  // but before drawing, move the coordinates a bit using perlin noise
  strokeWeight(3);
  stroke(0);
  for(int i=0; i<4; i++) {
    x = xs[i]; //add noise here
    y = ys[i]; //add noise here
    line(x,0,x,height);
    line(0,y,width,y);
  }
  
  // now fill three color fields starting at the coordinates 
  // we picked at the beginning
  
}




