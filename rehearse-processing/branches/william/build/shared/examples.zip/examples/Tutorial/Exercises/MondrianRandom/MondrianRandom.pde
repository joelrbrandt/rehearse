// Mondrian version 2
// generate lines and fills randomly

void setup() {
  
  //some variables we'll need:
  int x,y; // hold generated x and y coordinates
  color c; // hold generated color
  color white = color(255);
  color black = color(0);
    
  //set size to 200x200 pixels
  //set background to white
  
  // make the stroke 3 pixels wide
  // make it black

  // draw some vertical lines
  int vLines = 4; //this many lines
  //for each line:
  
    // generate a random x coordinate
    
    // draw a line from (x,0) to (x,height)
    
  

  //draw some horizontal lines
  int hLines=3; //this many lines
  //for each line:
    // generate a random y coordinate
    //draw a line from (0,y) to (width,y)
  
  //fill the space in between lines with primary colors
  int fields = 4; // this many color fields
  //for each field
    //pick a random x,y coordinate
    //and a random primary color
    // fill it in using the boxFill() algorithm
  
}

