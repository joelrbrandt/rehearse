
int NUM_LETTERS = 30;
Letter[] letters = new Letter[NUM_LETTERS];

PFont font;
int x=5;
int y=41;
char [] chars = new char[10];
int ix = 0;
void setup() {
  size(360,200);
  background(0);
  font = loadFont("Monospaced-36.vlw"); 
  textFont(font);
  fill(0, 102, 153);
}

void draw() {
  background(0);
  for(int i=0; i<NUM_LETTERS; i++) {
    if(letters[i]!=null) {
    letters[i].draw();
    }
  }
}

void keyTyped() {
  println(key);
  
  letters[ix] = new Letter(key,x,5+36); 
  ix = (ix+1) % NUM_LETTERS;
  x = (x+36) % width;
}

