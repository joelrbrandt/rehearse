//Draw a HSB color picker 
//Choose a Hue on the side bar with a mouse click,
//then print HSB and RGB color values to the console
//when the user clicks inside the main color slice

int h=0; //hue

void setup() {
  colorMode(HSB);
  size(256+16,256);
  drawSlice(h);
  drawBar();
}

// empty draw function - all action happens in mouse handler function
void draw() {}

// draw a 2D slice of HSB space at the hue given by variable hue
void drawSlice(int h) {
for(int s=0; s<256; s++) {
    for(int b=0; b<256; b++) {
      //at position (x,y) draw a pixel of color(red=x,green=y,blue=128)
      stroke(h,s,b);
      point(s,255-b);
    }
  }
}

// draw the hue bar on the right side of the window
void drawBar() {
  // iterate over 256 possible hue values
  for(int h=0;h<256;h++) {
    //draw a line of color (hue, 255,255)
    //from (256,hue) to (width,hue)
    stroke(h,255,255);
    line(256,h,width,h);
  }
}

// function that is called when the mouse button is pressed
void mousePressed() {
  if(mouseX<256) {
    // picked a color in the main field:
    // print HSB and RGB values to console
    print("hue: "+h+"; ");
    print("saturation: "+mouseX+"; ");
    println("brightness: "+(255-mouseY));
    color c = color(h,mouseX,255-mouseY);
    print("red: "+int(red(c))+"; ");
    print("green: "+int(green(c))+"; ");
    println("blue: "+int(blue(c)));
    
    
  } else {
    //picked a new hue on the hue bar:
    //save value and redraw the 2d slice
    h=mouseY;
    drawSlice(h);
  }
}
