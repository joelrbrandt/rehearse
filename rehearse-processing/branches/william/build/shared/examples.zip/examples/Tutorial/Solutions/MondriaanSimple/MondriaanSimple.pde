// mondriaan_00

void setup() {
  
  // make our canvas 200 x 200 pixels large
  size(200,200);  
  
  // set background to white
  background(255);
  
  // don't draw outlines around rectangles
  noStroke();

  // draw some colored rectangles
  // set fill color to red
  fill(255,0,0);

  // draw rect with upper left corner at (10,10)
  // and width and height of 50 
  rect(10,10,50,50);

  //set fill color to blue
  fill(0,0,255);
  
  // draw rect with upper left corner at (0,60)
  // width 10 and height 80
  rect(0,60,10,80);

  // set fill color to yellow
  fill(255,255,0);
  
  // draw rect with upper left corner at (60,140)
  // and width 10, height 10
  rect(60,140,140,10);

  // now draw lines in black
  // turn off fill
  noFill();
  // set stroke color to black
  stroke(0);
  // set the width of the stroke to 3 pixels
  strokeWeight(3);

  // draw horizontal lines
  // draw line from (0,10) to (200,10)
  line(0,10,width,10);
  // draw line from (0,60) to (200,60)
  line(0,60,width,60);
  // draw line from (0,140) to (200,140)
  line(0,140,width,140);
  // draw line from (0,150) to (200,150)
  line(0,150,width,150);
  
  // draw vertical lines
  // draw line from (10,0) to (10,200)
  line(10,0,10,height);
  // draw line from (60,0) to (60, 200)
  line(60,0,60,height);
}

