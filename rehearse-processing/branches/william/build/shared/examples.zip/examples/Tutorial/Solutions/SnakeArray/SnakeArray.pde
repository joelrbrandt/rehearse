// SnakeArray:
// draw a snake that follows the mouse using arrays

// declare two arrays that hold x,y coordinates
// of snake
int xs[] = new int[50];
int ys[] = new int[50];

void setup() {
  size(150,150);
  smooth();
  colorMode(HSB);
  strokeWeight(3); 
  
  //initialize all array elements to 0
  for(int i=0; i< xs.length; i++) {
    xs[i]=0;
    ys[i]=0;
  }
}


void draw() {
  //clear screen
  background(64);

  //shift arrays over by one
  for(int i=xs.length-1; i>=1; i--) {
    xs[i]=xs[i-1];
    ys[i]=ys[i-1];
  }
  
  //if mouse pressed, save mouse position at head of array
  if(mousePressed) {
    xs[0]=mouseX;
    ys[0]=mouseY;
  } 
  
  //now draw what's in our array
  //iterate over arrays
  for(int i=1; i< xs.length; i++) {
    // set a different hue for each element of the snake
    stroke(i+50,255,255);
    // optional: make stroke thicker at the beginning of the snake
    // and thinner towards the end
    strokeWeight((xs.length-i)/5);
    //draw a line from one snake point to the next
    line(xs[i-1],ys[i-1],xs[i],ys[i]);
  }
}

