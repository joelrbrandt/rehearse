// SpheresStatic - understanding hierarchical transformations
// 24 spheres surrount a central sphere.

// how many sectors do we want to subdivide a circle into?
int sectors = 24;

// the central angle of each sector in radians? (360 degrees/sectors) in radians 
float angle = radians(360/sectors);

void setup() {
  size(150,150);
  noStroke();
  smooth();
  background(128);
  colorMode(HSB);
  //move coordinate system origin to center of window

  //draw the center sphere of size(15,15)
  ellipse(0,0,15,15);

  // iterate of each sector to draw orbiting spheres:

    //save current transformation so we can restore it later
   
    //rotate to i-th sector
    
    // move away from the center along the x axis of the rotated coord system 
   
    // draw a smaller sphere
    
    
    //restore the saved coordinate system
    
  //
}

