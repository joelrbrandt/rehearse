// SpheresStatic - understanding hierarchical transformations
// 24 spheres surrount a central sphere.

// how many sectors do we want to subdivide a circle into?
int sectors = 24;

// the central angle of each sector in radians? (360 degrees/sectors) in radians 
float angle = radians(360/sectors);

void setup() {
  size(150,150);
  noStroke();
  smooth();
  background(128);
  colorMode(HSB);
  //move coordinate system origin to center of window
  translate(width/2,height/2);
  
  //draw the center sphere
  ellipse(0,0,15,15);

  // iterate of each sector to draw orbiting spheres:
  for(int i=0; i<sectors; i++) {
    //save current transformation so we can restore it later
    pushMatrix();
    //rotate to i-th sector
    rotate(i*angle);
    // move away from the center along the x axis of the rotated coord system 
    translate(40,0);
    // draw a smaller sphere
    fill(map(i,0,sectors,0,255),255,255);
    ellipse(0,0,8,8);
    
    //restore the saved coordinate system
    popMatrix();
  }
}

